// Exports the "accordion" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/accordion')
//   ES2015:
//     import 'tinymce/plugins/accordion'
require('./plugin.js');